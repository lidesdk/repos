-- for path in package.path  : delimi ';' do print(path) end
-- for path in package.cpath : delimi ';' do print(path) end

alien_core_values = { todouble = true, isnull = true, toint = true, tofloat = true, touint = true, rewrap = true, unwrap = true, sizeof = true, platform = true, align = true, toulong = true, memcpy = true, buffer = true, table = true, funcptr = true, errno = true, wrap = true, callback = true, tostring = true, toushort = true, tolong = true, default = true, tochar = true, toshort = true, memset = true, load = true, tag = true }

for value in next, require 'alien.core' do
	assert(alien_core_values[tostring(value)], ('Field "alien.core.%s" doesn\'t exists.'):format(tostring(value)))
end

alien_struct_values = { offset = true, pack = true, size = true, unpack = true,  }

for value in next, require 'alien.struct' do
	assert(alien_struct_values[tostring(value)], ('Field "alien.struct.%s" doesn\'t exists.'):format(tostring(value)))
end


for k,v in pairs(alien.core) do
	print(k,v)
end