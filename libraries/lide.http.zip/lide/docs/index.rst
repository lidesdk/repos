.. include:: ./welcome.rst

.. toctree::
	:hidden:
	:caption: Empezando con Lide
	
	./welcome

.. toctree::
	:hidden:
	:caption: Modelo de OOP

	./oop-intro
	./access_modifiers
	./oop/class_methods
	
.. toctree::
	:hidden:
	:caption: Referencia de la API

	./types
	./classes
