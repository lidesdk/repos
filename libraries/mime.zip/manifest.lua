t = {}

t.depends = { 'ltn12' }

return t