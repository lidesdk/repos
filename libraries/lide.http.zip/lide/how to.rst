Como usar el framework

Creamos un archivo

Dentro del archivo:


--- Importar las clases/funciones que necesitamos:
--	En éste caso serian las clases Form y Button, y la función messagebox
	
	local Form   = lide.classes.widgets.form
	local Button = lide.classes.widgets.button
    local MessageBox = lide.core.base.messagebox

--- Creamos el nuevo formulario:
--  Le damos las propiedades Name y Title que corresponden al Titulo de la ventana y el nombre del objeto

	form1 = Form:new { Name = 'form1', -- Notese que la variable que contiene el formulario tambien se llama form1
       	Title = 'Window Caption'
	};

--- Creamos un nuevo botón dentro del formulario 'form1'
--  Esta vez le damos las posiciones y el texto que debe tener el botón

button1 = Button:new { Name = 'button1', Parent = form1,
        PosX = 10, PosY = 30,
        Text = 'Click me!',
};

--- Conectamos el evento 'onClick' del botón 'button1'
--  Lanzamos un mensaje

button1.onClick : setHandler ( function ( ... )
        MessageBox 'Hello world!'
end );

form1:show(true)