--local requests = require('src/requests')
--local inspect = require('inspect')
--
----describre("All requests test", function()
  ----describre("GET request", function()
    ----it(("can make basic get requests", function()
      local http = require 'http'

      local url = 'http://httpbin.org/get'

      local response = http.get(url)
      local json_data, err = response.json()

      assert(200, response.status_code)

--      --describre("GET request (secure)", function()
  --      --it(("can make basic get requests w--it(h https", function()
          local url = 'https://httpbin.org/get'

          local response = http.get(url)
          local json_data, err = response.json()

          assert(200 == response.status_code, response.status_code)
          --assert.falsy(err)
          --assert(url, json_data.url)
        ----end)
      ----end)

      ----describre("POST request", function()
      -- -- --it(("can do basic post commands", function ()
          local url = 'http://httpbin.org/post'

          local response = http.post(url, {data = 'blah'})
          local json_data, err = response.json()

          assert(200 == response.status_code, response.status_code)
          --assert.falsy(err)
          assert('blah' == json_data.data, json_data.data)
          assert('4' == json_data.headers['Content-Length'], json_data.headers['Content-Length'])

          response = http.post(url, {data = ''})
          json_data, err = response.json()

          assert(200 == response.status_code, response.status_code)
          --assert.falsy(err)
          assert('' == json_data.data, json_data.data)
          assert('0' == json_data.headers['Content-Length'], json_data.data)
        ----end)

          ----it(("can send a json encoded table", function ()
            local url = 'http://httpbin.org/post'
            local data = { stuff = true, otherstuff = false }
            local response = http.post(url, {data = data})
            local json_data = response.json()

            local json = require('cjson')
            local output_data = json.encode(data)
            assert(output_data == json_data.data)

--            --describre("DELETE request", function()
--              --it(("can make basic delete requests", function()
                local url = 'http://httpbin.org/delete'

                local response = http.delete(url, {data = 'delete!'})
                local json_data, err = response.json()

                assert(200 == response.status_code)
                --assert.falsy(err)
                assert('delete!' == json_data.data)
  --            --end)
  --          --end)

            ----describre("PUT request", function()
--              --it(("can make basic put requests", function()
                local url = 'http://httpbin.org/put'

                local response = http.put(url, {data = 'put'})
                local json_data, err = response.json()

                assert(200 == response.status_code)
                --assert.falsy(err)
                assert('put' == json_data.data)
  --            --end)
  --          --end)


--          --end)
--        --end)

  --describre("OPTIONS request", function()
    --it(("can make options requests", function()
      local url = 'http://httpbin.org/get'

      local response = http.options(url)

      assert(200 == response.status_code)
      assert('HEAD, OPTIONS, GET' == response.headers.allow)
    --end)
  --end)

  --describre("HEAD request", function()
    --it(("can make head requests", function()
      local url = 'http://httpbin.org/get'

      local response = http.head(url)

      assert(200 == response.status_code)
      assert(tonumber(response.headers['content-length']) > 0 == true)
      assert('' == response.text)
    --end)
  --end)

--end)

--describre("Authentication", function()

  --describre("Digest", function()

    --it(("should work w--it(h GET", function()
      local url = 'http://httpbin.org/digest-auth/auth/user/passwd'
      local response = http.get(url, {auth=http.HTTPDigestAuth('user', 'passwd')})

      assert(200 == response.status_code)
      assert(1 == response.auth.nc_count)

      local response_text = response.text
      local nonce = response.auth.nonce

      -- Should be able to reuse the previous authentication
      response = http.get(url, {auth = response.auth, cookies = response.cookies })

      assert(200 == response.status_code)
      assert(2   == response.auth.nc_count)
      assert(response.auth.nonce== nonce)
      assert(response_text == response.text)

      -- Should be able to reuse the previous authentication
      response = http.get(url, {auth = response.auth, cookies = response.cookies })

      assert(200 == response.status_code)
      assert(3   == response.auth.nc_count)
      assert(response.auth.nonce == nonce)
      assert(response_text == response.text) 
      -- W--it(hout the cookies this should have to reauthenticate
      response = http.get(url, {auth = response.auth})

      assert(1   == response.auth.nc_count)
      assert(200 == response.status_code)
    --end)

  --end)

  --describre("Basic", function()

    --it(("should work w--it(h GET", function()
      local url = 'http://httpbin.org/basic-auth/user/passwd'
      local response = http.get(url, {auth=http.HTTPBasicAuth('user', 'passwd')})
      local json_data, err = response.json()

      assert(200  == response.status_code)
      assert(true == json_data.authenticated)

      response = http.get{url=url, auth=http.HTTPBasicAuth('user', 'passwd')}
      json_data, err = response.json()

      assert(200  == response.status_code)
      assert(true == json_data.authenticated)
    --end)
  --end)
--end)

--describre("XML", function ()

  --it(("should work w--it(h a basic xml", function ()
    local url = 'http://httpbin.org/xml'
    local response = http.get(url)
    local xml_body = response.xml()

    assert(200, response.status_code)
    assert("t--it(le", xml_body[1][1].xml)
  --end)

  --it(("should fail w--it(h a non-xml response", function ()
    local url = 'http://httpbin.org/get'
    local response = http.get(url)
    --assert.has_errors(function () return response.xml() --end)
  --end)
--end)

--describre("Redirects", function()
  --it(("should work", function()
    local url = 'http://httpbin.org/redirect-to?url=google.com'
    local response = http.get(url, {allow_redirects = true})

--    assert(200 == response.status_code)

    response = http.get(url, {allow_redirects = false})
    assert(302 == response.status_code)
  --end)
--end)

--describre("Timeout", function()
  --it(("should work", function()
    local url = 'http://httpbin.org/delay/2'
    --assert.has.errors(function () return http.get(url, {timeout = 1}) --end)

    local response = http.get(url, {timeout = 3})
    assert(200 == response.status_code)
  --end)
--end)
print 'TEST OK'
      --assert(err)
      --assert(url, json_data.url)
    ----end)
  ----end)
--[[



  
  
]]

--[[
require 'lfs'

local http = require 'http.in--it('

url = 'http://speedtest.ftp.otenet.gr/files/test100k.db'

require 'lub'

if lide.platform.getOSName() == 'Linux' then
	_tmp_file = '/tmp/__readme.rst'
	os.execute 'rm /tmp/__readme.rst'
else
	_tmp_file = '__readme.rst'
	os.execute 'del __readme.rst'
end

io.stdout:wr--it(e '\n[lide test] - download file '

http.download(url, _tmp_file)

if io.open(_tmp_file) then	
	io.stdout:wr--it(e 'OK]\n'
else
	io.stdout:wr--it(e 'FAILED]\n'
	assert(false)
end

for k, v in pairs( package.path:delim ';' ) do
	print( k, v )
end
]]